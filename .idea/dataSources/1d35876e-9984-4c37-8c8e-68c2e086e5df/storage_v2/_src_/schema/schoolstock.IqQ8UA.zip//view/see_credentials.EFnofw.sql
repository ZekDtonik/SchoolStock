create view see_credentials as
  select concat(`schoolstock`.`users`.`name`, ' ', `schoolstock`.`users`.`lastname`) AS `username`,
         `schoolstock`.`users`.`status`                                              AS `userstatus`,
         `schoolstock`.`usergroups`.`guid`                                           AS `guid`,
         `schoolstock`.`usergroups`.`name`                                           AS `usergroupname`,
         `schoolstock`.`credentials`.`cid`                                           AS `cid`,
         `schoolstock`.`usergroups`.`active`                                         AS `groupactive`,
         `schoolstock`.`users`.`authid`                                              AS `authid`
  from ((`schoolstock`.`credentials` join `schoolstock`.`users` on ((`schoolstock`.`credentials`.`authid` =
                                                                     `schoolstock`.`users`.`authid`))) join `schoolstock`.`usergroups` on ((
    `schoolstock`.`usergroups`.`guid` = `schoolstock`.`credentials`.`guid`)));

