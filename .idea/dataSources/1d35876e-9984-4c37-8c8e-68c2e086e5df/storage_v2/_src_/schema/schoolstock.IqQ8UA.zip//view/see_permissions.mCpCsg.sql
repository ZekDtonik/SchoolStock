create view see_permissions as
  select `schoolstock`.`users`.`authid`     AS `authid`,
         `schoolstock`.`usergroups`.`perms` AS `permissions`,
         `schoolstock`.`credentials`.`cid`  AS `cid`,
         `schoolstock`.`users`.`status`     AS `status`,
         `schoolstock`.`usergroups`.`name`  AS `usergroupname`,
         `schoolstock`.`usergroups`.`guid`  AS `guid`
  from ((`schoolstock`.`users` left join `schoolstock`.`credentials` on ((`schoolstock`.`users`.`authid` =
                                                                          `schoolstock`.`credentials`.`authid`))) left join `schoolstock`.`usergroups` on ((
    `schoolstock`.`usergroups`.`guid` = `schoolstock`.`credentials`.`guid`)));

