create view see_usergroups as
  select `schoolstock`.`usergroups`.`guid`         AS `guid`,
         `schoolstock`.`usergroups`.`registerDate` AS `registerDate`,
         `schoolstock`.`usergroups`.`name`         AS `name`,
         `schoolstock`.`usergroups`.`description`  AS `description`,
         `schoolstock`.`usergroups`.`perms`        AS `perms`,
         `schoolstock`.`usergroups`.`active`       AS `active`
  from `schoolstock`.`usergroups`;

